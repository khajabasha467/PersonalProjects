﻿using MVCFormSubmitSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCFormSubmitSample.Controllers
{
    public class ContactController : Controller
    {
        // GET: Contact
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SaveContact(Contact contact)
        {

            Session["ContactSessionKey"] = contact;
            return Json(new { SessionKey = "ContactSessionKey" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Result(string sessionKey)
        {
            var contact = Session[sessionKey] as Contact;
            return Json(contact, JsonRequestBehavior.AllowGet);
        }
    }
}
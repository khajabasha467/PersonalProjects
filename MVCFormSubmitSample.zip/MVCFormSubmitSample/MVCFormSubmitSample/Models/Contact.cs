﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCFormSubmitSample.Models
{
    public class Contact
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string State { get; set; }
        public bool IsMarried { get; set; }
    }
}
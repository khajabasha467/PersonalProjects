﻿using OACWebAPI.Business;
using OACWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OACWebAPI.Controllers
{
    public class OACController : ApiController
    {
        [HttpPost]
        public IHttpActionResult RegisterEvent(Event registerEvent)
        {
            OACBusiness oacBusiness = new OACBusiness();
            int EventId=oacBusiness.RegisterEvent(registerEvent);
            return Ok("Event Id:"+ EventId);
        }


        [HttpPost]
        public IHttpActionResult RegisterGuest(Guest guest)
        {
            OACBusiness oacBusiness = new OACBusiness();
            bool registeredguest = oacBusiness.RegisterGuest(guest);
            return Ok(registeredguest);
        }


    }
}
